// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iomanip> // needed for setw
#include <iostream>
#include <limits> // needed for clearing the extra input

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    
    const std::string account_number = "CharlieBrown42"; // account_number stays here and does not change


    char user_input[20]; // user_input will be limited to 19 characters + 1 for the null terminator

    std::cout << "Enter a value (max 19 characters): ";

    
    std::cin >> std::setw(20) >> user_input; // setw makes sure no more than 19 characters goes into user_input

    // this function will check if the user typed too many characters
    if (std::cin.peek() != '\n') {
        std::cout << "Warning: You entered too many characters. Extra input was ignored." << std::endl;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // this clears the rest of the input so it doesn�t mess with the rest of the program
    }

    // show what the user typed and the secret account number
    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}
